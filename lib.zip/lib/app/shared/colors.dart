import 'dart:ui';

const purple_color =Color(0xFFD8C2FF);
const dark_purple_color =Color(0xFFC7A7FF);
const blue_color =Color(0xFFCCDBFD);
const dark_blue_color =Color(0xFFA4BFFC);
const white_color =Color(0xFFFFFFFF);
const gray_color =Color(0xFFE5EEF2);
const text_gray_color =Color(0xFF64748B);
const dark_color =Color(0xFF334155);
const beige_color =Color(0xFFF7F6F0);

